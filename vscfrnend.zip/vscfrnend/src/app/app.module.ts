import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { SignupComponent } from './signup/signup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageComponent } from './page/page.component';
import {MatToolbarModule} from '@angular/material';
import {MatProgressSpinnerModule} from '@angular/material';
import { MapsComponent } from './maps/maps.component';
import {AgmCoreModule, GoogleMapsAPIWrapper} from '@agm/core';
import { FeedbackComponent } from './feedback/feedback.component';
import { AboutComponent } from './about/about.component';
import { GooglePlacesDirective } from './google-places.directive';
import { GeoComponent } from './geo/geo.component';
import { HttpModule } from '@angular/http';
import { NavheaderComponent } from './navheader/navheader.component';
import { PhoneNumberValidator } from './signup/phone-number.validator';
import { ConfirmPasswordValidator } from './signup/confirm-password.validator';
import { ProfileComponent } from './profile/profile.component';
import { StrttripComponent } from './strttrip/strttrip.component';
import { ChatModule } from './chat/chat.module';
import { EncrDecrService } from './encr-decr.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { DataserviceService } from './dataservice.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HereMapComponent } from './here-map/here-map.component';
import { LogoutComponent } from './logout/logout.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { AftastarttripComponent } from './aftastarttrip/aftastarttrip.component';
import { ViewpendingtripsComponent } from './viewpendingtrips/viewpendingtrips.component';
import { HttpClientJsonpModule } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http'; 
import { WeatherComponent } from './weather/weather.component';
import { FahrenheitPipe } from './fahrenheit.pipe';
import { MomentPipe } from './moment.pipe';
import { BoardComponent } from './board.component';
import { CellComponent } from './cell.component';
import { ViewCancelledComponent } from './view-cancelled/view-cancelled.component';
import { ViewCompletedComponent } from './view-completed/view-completed.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    PageComponent,
    MapsComponent,
    FeedbackComponent,
    AboutComponent,
    GooglePlacesDirective,
    GeoComponent,
    NavheaderComponent,
    ProfileComponent,
    StrttripComponent,
    HereMapComponent,
    LogoutComponent,
    ForgotpasswordComponent,
    AftastarttripComponent,
    ViewpendingtripsComponent,
    WeatherComponent,
    FahrenheitPipe,
    MomentPipe,
    BoardComponent,
    CellComponent,
    ViewpendingtripsComponent,
    ViewCancelledComponent,
    ViewCompletedComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    HttpClientJsonpModule,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
    ChatModule,
    MatProgressSpinnerModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
    NgbModule.forRoot(),

   
    AgmCoreModule.forRoot({
      apiKey:'AIzaSyAp_4m7oqeh39oGUPiT4lGR7Yf6R-2cKxY'
    })
    

   

  ],
  providers: [PhoneNumberValidator,
              ConfirmPasswordValidator,
              EncrDecrService,
              DataserviceService,
              GoogleMapsAPIWrapper],
  bootstrap: [AppComponent]
})
export class AppModule { }
