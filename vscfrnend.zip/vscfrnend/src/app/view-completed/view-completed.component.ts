import { Component, OnInit } from '@angular/core';
import { strttrip } from '../strttrip/strttrip';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-view-completed',
  templateUrl: './view-completed.component.html',
  styleUrls: ['./view-completed.component.css']
})
export class ViewCompletedComponent implements OnInit {
  l:any;
  i:strttrip; 
  sendTrip:strttrip;
  
  index:number;
  
  empty:boolean = false;



  
    constructor(private service:DataserviceService) { 
   

      this.l=this.service.getComplete();
      console.log("----full---")
      console.log("Printing l"+this.l);

      if(this.l == null){
        this.empty = true;
      }
  
    }
  
    ngOnInit() {
  
    }
}
