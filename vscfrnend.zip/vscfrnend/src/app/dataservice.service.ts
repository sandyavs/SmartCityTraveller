import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Signup } from './signup/signup';

import { profile } from './profile/profile';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { login } from './login';
import { strttrip } from './strttrip/strttrip';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {

  res:any;
  
  constructor(private http:Http) { }
   
  private data:login;
  private tripData:any;
  private trip:strttrip;
  private Cantrip:strttrip;
  private Comtrip:strttrip 
  geodata:any;


  setOption(value) { 
    console.log("IN SET") 
    //  sessionStorage.setItem('updateOb',JSON.stringify(value))  

     this.data = JSON.parse(sessionStorage.getItem('updateObj'));
     console.log('setdata:'+JSON.stringify(value));
   }  
   
   getOption() {  
     return JSON.parse(sessionStorage.getItem('updateObj'));;  
   }  
  

   setTrip(value) { 
    console.log("IN SET") 
    this.data = JSON.parse(sessionStorage.getItem('tripOb'));
     console.log('setdata:'+JSON.stringify(value));
   }  
   
   getTrip() {  
     return JSON.parse(sessionStorage.getItem('tripOb'));;  
   }  


   setCancelled(value) { 
    console.log("IN SET") 
    this.Cantrip = JSON.parse(sessionStorage.getItem('cancelled'));
     console.log('setdata:'+JSON.stringify(value));
   }  
   
   getCancelled() {  
     return JSON.parse(sessionStorage.getItem('cancelled'));;  
   } 


   setComplete(value) { 
    console.log("IN SET") 
    this.Comtrip = JSON.parse(sessionStorage.getItem('completed'));
     console.log('setdata:'+JSON.stringify(value));
   }  
   
   getComplete() {  
     return JSON.parse(sessionStorage.getItem('completed'));;  
   }



   setgeoarea(value){
     this.geodata=value;
     console.log("IN GEOAREA"+this.geodata);

   }

   getgeoarea(){
     return this.geodata;
   }


   setfetchTrip(value) { 
    console.log("IN SET") 
    //  sessionStorage.setItem('updateOb',JSON.stringify(value))  

     this.tripData = JSON.parse(sessionStorage.getItem('fetchTrip'));
     console.log('setdata:'+JSON.stringify(value));
   }  
   

   getfetchTrip() {  
    return JSON.parse(sessionStorage.getItem('fetchTrip'));;  
  }  
 

  addregdetails(data) : Promise<Signup> {
    this.res = this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/setReg', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler)
    return this.res;
  }

  
  UserLogin(data) : Promise<login> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/login', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler);
    
    
  }

  updation(data) : Promise<profile> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/update', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler)
  }

  ForgotPass(data) : Promise<any> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/forgot', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler);  
  }

  AddTrip(data) : Promise<any> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/Trips', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler);  
  }
  
  fetchTrips(data) : Promise<any> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/fetchTrips', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler);  
  }

  fetchCancelledTrips(data) : Promise<any> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/fetchCANCELTrips', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler);  
  }


  fetchCompletedTrips(data) : Promise<any> {
    return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/fetchCOMPLETETrips', data)
    .toPromise()
    .then(response => response.json())
    .catch(this.errorHandler);  
  }


Cancelled(data) : Promise<any> {
  return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/Completed', data)
  .toPromise()
  .then(response => response.json())
  .catch(this.errorHandler);
}

Completed(data) : Promise<any> {
  return this.http.post('http://localhost:8765/SmartCityTraveller/SmartApi/Completed', data)
  .toPromise()
  .then(response => response.json())
  .catch(this.errorHandler);
}

  errorHandler(error){
    return Promise.reject(error.json())
  }
}
