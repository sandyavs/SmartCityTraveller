import { Component, OnInit } from '@angular/core';
import { strttrip } from '../strttrip/strttrip';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-view-cancelled',
  templateUrl: './view-cancelled.component.html',
  styleUrls: ['./view-cancelled.component.css']
})
export class ViewCancelledComponent implements OnInit {
  l:any;

  sendTrip:strttrip;
  empty:boolean = false;
  index:number;
  
    constructor(private service:DataserviceService) { 
  
      this.l=this.service.getCancelled();
      console.log("----full---");
      console.log("Printing l"+this.l);

      if(this.l == null){
        this.empty = true;
      }
  
    }
  
    ngOnInit() {
  
    }
}
