import { Local } from 'protractor/built/driverProviders';

export class Signup{
    uname:string;
    password:string;
    name:string;
    address:string;
    phonenumber:string;
    emailed:string;
    cityofbirth:string;
    dateofbirth:Date;
    // usertype:string;
    gender:string;
}