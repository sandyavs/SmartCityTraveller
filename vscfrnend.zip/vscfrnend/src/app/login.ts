export class login{
    rid:number;
    uname:string;
    password:string;
    name:string;
    address:string;
    phonenumber:string;
    emailed:string;
    cityofbirth:string;
    dateofbirth:Date;
    // usertype:string;
    gender:string;
}