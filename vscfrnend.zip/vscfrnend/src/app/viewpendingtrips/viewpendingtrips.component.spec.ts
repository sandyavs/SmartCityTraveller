import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpendingtripsComponent } from './viewpendingtrips.component';

describe('ViewpendingtripsComponent', () => {
  let component: ViewpendingtripsComponent;
  let fixture: ComponentFixture<ViewpendingtripsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewpendingtripsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewpendingtripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
