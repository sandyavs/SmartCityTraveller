import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { strttrip } from '../strttrip/strttrip';

@Component({
  selector: 'app-viewpendingtrips',
  templateUrl: './viewpendingtrips.component.html',
  styleUrls: ['./viewpendingtrips.component.css']
})
export class ViewpendingtripsComponent implements OnInit {
l:any;
listTrip:strttrip[];
tripObj:strttrip;
i:strttrip;
date1:Date;

sendTrip:strttrip;

index:number;

empty:boolean = false;

successMessage: string;
errorMessage: string;

  constructor(private service:DataserviceService) { 

    this.l=this.service.getfetchTrip();
    console.log("----full---")
    console.log("Printing l"+this.l);
this.date1 = new Date();
this.date1.toLocaleTimeString();

    if(this.l == null){
      this.empty = true;
    }
    else{
      this.empty = false
    }

  }

  ngOnInit() {

  }

Cancelled(trip){

  this.index = this.l.indexOf(trip);
  console.log(this.index);
  
  this.l.splice(this.index,1) 

  this.sendTrip = new strttrip();
  

  this.sendTrip.setStart(trip.starttime)
  this.sendTrip.setEnd(trip.endtime)
  this.sendTrip.setPlace(trip.place)
  this.sendTrip.setRid(trip.rid)
  this.sendTrip.setTid(trip.tid)
  this.sendTrip.setStatus("CANCELLED");

  this.service.Cancelled(this.sendTrip).then(sign => {
    this.tripObj = sign;
     return sign;

}).catch(error => {
   this.errorMessage = error.message
return null;
})
}

Completed(trip){
  this.index = this.l.indexOf(trip);
  console.log(this.index);
  
  this.l.splice(this.index,1) 
  
  this.sendTrip = new strttrip();


  this.sendTrip.setStart(trip.starttime)
  this.sendTrip.setEnd(trip.endtime)
  this.sendTrip.setPlace(trip.place)
  this.sendTrip.setRid(trip.rid)
  this.sendTrip.setTid(trip.tid)
  this.sendTrip.setStatus("COMPLETED");


  console.log(this.sendTrip)
  this.service.Completed(this.sendTrip).then(sign => {
    this.tripObj = sign;
     return sign;

}).catch(error => {
   this.errorMessage = error.message
return null;
})
}

}
