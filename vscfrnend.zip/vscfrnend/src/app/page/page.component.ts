import { Component, OnInit, Input } from '@angular/core';
import { login } from '../login';
import { AuthenticationService } from '../service/authentication.service';
import { DataserviceService } from '../dataservice.service';
import { strttrip } from '../strttrip/strttrip';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {
  loadComponent =false;
  loadcontact=false;
  loadabout =false;
  loadgeo =false;
  loadprofile=false;
  loadstr =false;
  loadpentrip=false;
  loadglobe = true;
  navState=true;
  loadLogin = false;
  confirmLogout = false;
  state=false;
  viewPending = false;
  public currentuser:login;  

  viewCancelled = false;
  viewComplete=false;

  successMessage: string;
  errorMessage: string;
  l:strttrip;
  listTrip :strttrip[] ;
  listTripcan:strttrip[];
  listTripcom:strttrip[];
  rid:number;
  loadweather: boolean;

  // @Input()
  // chosenuser:login

  constructor(private loginService:AuthenticationService,private loginserv:DataserviceService,private dataservice:DataserviceService){ 

    this.currentuser=this.loginserv.getOption()
    console.log('currentuser'+JSON.stringify(this.currentuser));
  }



  loadMyChildComponent() {
    this.loadComponent = true;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo =false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
    this.viewCancelled = false;
    this.viewComplete=false;
    this.loadweather = false; 

  }
  
  loadMyProfileComponent() {
  this.loadComponent = false;
  this.loadcontact = false;
  this.loadabout = false;
  this.loadgeo =false;
  this.loadprofile=true;
  this.loadstr =false;
  this.loadpentrip=false;
  this.loadglobe =false;
  this.viewPending =false;
  this.loadweather = false; 

  this.viewCancelled = false;
  this.viewComplete=false;
}
  loadMyContactComponent(){
    this.loadComponent =false;
    this.loadcontact = true;
    this.loadabout =false;
    this.loadgeo =false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
    this.viewCancelled = false;
    this.viewComplete=false;
    this.loadweather = false; 

  }

  loadMyAboutComponent(){
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = true;
    this.loadgeo =false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
    this.viewCancelled = false;
    this.viewComplete=false;
    this.loadweather = false; 

  }

  loadMygeoComponent(){
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo =true;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
    this.viewCancelled = false;
    this.viewComplete=false;
    this.loadweather = false; 

  }

  loadMyAboutStrtTrip(){
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =true;
    this.loadpentrip=false;
    this.loadglobe =false;
    this.viewPending =false;
    this.viewCancelled = false;
    this.viewComplete=false;
    this.loadweather = false; 

  }

  loadMyAboutpendingTrip(){
    //alert("load pending trip");
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=true;
    this.loadglobe =false; 
    this.viewPending =false; 
    this.viewCancelled = false;
    this.viewComplete=false;  
    this.loadweather = false; 
  }

  loadweatherComponent(){
    this.viewPending =false; 
    this.viewCancelled = false;
    this.viewComplete=false;  
    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadweather = true;
    this.loadglobe =false; 
    this.viewPending =false;
      
  }
  loadMyviewPendingTrip(){

    

    this.errorMessage = null
    this.successMessage = null
    this.dataservice.fetchTrips(this.currentuser).then(sign => {
      this.listTrip = sign;
      // console.log(sign);
      // console.log(this.l);
      sessionStorage.setItem('fetchTrip',JSON.stringify(this.listTrip))
      this.dataservice.setfetchTrip(JSON.parse(sessionStorage.getItem('fetchTrip')))

       return sign;
 
 }).catch(error => {
     this.errorMessage = error.message
 return null;
 })
 



    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;  
    this.viewPending = true;
    this.viewCancelled = false;
    this.viewComplete=false;
    this.loadweather = false; 

  }



  
  loadMyviewCancelled(){

    

    this.errorMessage = null
    this.successMessage = null
    this.dataservice.fetchCancelledTrips(this.currentuser).then(sign => {
      this.listTripcan = sign;
      // console.log(sign);
      // console.log(this.l);
      sessionStorage.setItem('cancelled',JSON.stringify(this.listTripcan))
      this.dataservice.setCancelled(JSON.parse(sessionStorage.getItem('cancelled')))

       return sign;
 
 }).catch(error => {
     this.errorMessage = error.message
 return null;
 })
 



    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;  
    this.viewPending = false;
    this.viewCancelled = true;
    this.viewComplete=false;
    this.loadweather = false; 

  }


  loadMyviewComplete(){

    

    this.errorMessage = null
    this.successMessage = null
    this.dataservice.fetchCompletedTrips(this.currentuser).then(sign => {
      this.listTripcom = sign;
      // console.log(sign);
      // console.log(this.l);
      sessionStorage.setItem('completed',JSON.stringify(this.listTripcom))
      this.dataservice.setComplete(JSON.parse(sessionStorage.getItem('completed')))

       return sign;
 
 }).catch(error => {
     this.errorMessage = error.message
 return null;
 })
 



    this.loadComponent =false;
    this.loadcontact = false;
    this.loadabout = false;
    this.loadgeo = false;
    this.loadprofile=false;
    this.loadstr =false;
    this.loadpentrip=false;
    this.loadglobe =false;  
    this.viewPending = false;
    this.viewCancelled = false;
    this.viewComplete=true;
    this.loadweather = false; 

  }




  changeState(){
    this.navState=false;
    this.loadLogin=true;
   }


  ngOnInit() {
  }

  generateAlert(){
    this.state = confirm("Confirm LOGOUT?");
    if(this.state){
      this.confirmLogout=true;
      this.navState = false;
      this.loadLogin=false;
      this.loginService.logOut();  
    }
}


}