import { setCurrentDirectiveDef } from '@angular/core/src/render3/state';

export class strttrip{
    rid:number;
    starttime:Date;     
    endtime:Date;
    status:string;
    place:string;
    tid:number;


    setRid(value){
    this.rid = value;
    }

    getRid(){
        return this.rid;
    }

    setStart(value){
      this.starttime = value;
    }

    getStart(){
        return this.starttime; 
    }

    setEnd(value){
        this.endtime=value;
    }

    getEnd(){
        return this.endtime;
    }

    setStatus(value){
        this.status = value;
    }

    getStatus(){
        return this.status;
    }

    setPlace(value){
        this.place = value;
        }
    
        getPlace(){
            return this.place;
        }

        
    setTid(value){
        this.tid = value;
        }
    
        getTid(){
            return this.tid;
        }
}

