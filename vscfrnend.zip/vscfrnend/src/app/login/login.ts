export class login{
    uname:string;
    password:string;
    phonenumber:string;
}