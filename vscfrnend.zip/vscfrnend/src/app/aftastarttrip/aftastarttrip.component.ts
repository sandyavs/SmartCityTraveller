import { Component, OnInit, Input } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { strttrip } from '../strttrip/strttrip';

@Component({
  selector: 'app-aftastarttrip',
  templateUrl: './aftastarttrip.component.html',
  styleUrls: ['./aftastarttrip.component.css']
})
export class AftastarttripComponent implements OnInit {
  area:string[] =[]
  area1:any;
  i:string;
  place:string="";

  successMessage: string;
  errorMessage: string;

  l:strttrip;
  newob:strttrip;
  
  constructor(private dataservice:DataserviceService) { 
    this.l=this.dataservice.getTrip();
  }

  @Input()
  stripdetails:any;
  @Input()
  etripdetails:any;
  
  ngOnInit() {
    
  }
get(){
  this.area1=this.dataservice.getgeoarea();
  this.area.push(this.area1);
  return this.area;

  }

  confirmTrip(){
    this.errorMessage = null
    this.successMessage = null

    console.log("------In After Strart Trip-------")
    console.log(this.l.rid);
    console.log(this.l.starttime)
    console.log(this.l.endtime)
    console.log(this.l.status)
    console.log(this.l.place)

 for(this.i of this.area){
   this.place += this.i + "," 
 }



 this.newob = new strttrip();
 this.newob.setRid(this.l.rid);
 this.newob.setStart(this.l.starttime);
 this.newob.setEnd(this.l.endtime);
 this.newob.setStatus(this.l.status);
 this.newob.setPlace(this.place)

 this.dataservice.setTrip(this.newob)
 
 console.log(this.place);



 console.log("-------------")
 console.log(this.newob.rid);
 console.log(this.newob.starttime)
 console.log(this.newob.endtime)
 console.log(this.newob.status)
 console.log(this.newob.place)

 console.log("------In After Strart Trip-------")
    console.log(this.l.rid);
    console.log(this.l.starttime)
    console.log(this.l.endtime)
    console.log(this.l.status)
    console.log(this.l.place)

 this.dataservice.setgeoarea(this.place)

 this.dataservice.AddTrip(this.newob).then(sign => {
     this.newob = sign;
 return sign;

}).catch(error => {
    this.errorMessage = error.message
return null;
})

  }
}
