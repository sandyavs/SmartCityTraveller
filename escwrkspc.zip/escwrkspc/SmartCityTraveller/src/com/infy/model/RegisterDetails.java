package com.infy.model;

import java.time.LocalDate;

import com.infy.entity.RegType;

public class RegisterDetails {
	private Integer RId;
	private String uname;
	private String password;
	private String name;
	private String address;
	private String phonenumber;
	private String emailed;
	private String cityofbirth;
	private LocalDate dateofbirth;
//	private RegType usertype;
	private String gender;
	private String securityque;
	private String securityans;
	private String message;
	
	public String getSecurityque() {
		return securityque;
	}
	public void setSecurityque(String securityque) {
		this.securityque = securityque;
	}
	public String getSecurityans() {
		return securityans;
	}
	public void setSecurityans(String securityans) {
		this.securityans = securityans;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Integer getRId() {
		return RId;
	}
	public void setRId(Integer rId) {
		this.RId = rId;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getEmailed() {
		return emailed;
	}
	public void setEmailed(String emailed) {
		this.emailed = emailed;
	}
	public String getCityofbirth() {
		return cityofbirth;
	}
	public void setCityofbirth(String cityofbirth) {
		this.cityofbirth = cityofbirth;
	}
	public LocalDate getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(LocalDate dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

	
}



