package com.infy.model;


public class T_pending {
	
	private Integer PId;
	private Trips TId;

	public Integer getPId() {
		return PId;
	}

	public void setPId(Integer pId) {
		PId = pId;
	}

	public Trips getTId() {
		return TId;
	}

	public void setTId(Trips tId) {
		TId = tId;
	}
}
