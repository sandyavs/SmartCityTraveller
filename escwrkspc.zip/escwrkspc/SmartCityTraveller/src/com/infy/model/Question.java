package com.infy.model;

public class Question {
	private Integer QId;
	private String Que;
	public Integer getQId() {
		return QId;
	}
	public void setQId(Integer qId) {
		QId = qId;
	}
	public String getQue() {
		return Que;
	}
	public void setQue(String que) {
		Que = que;
	}
}
