package com.infy.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Trips {
private Integer tid;
private Integer rid;
private LocalDateTime starttime;
private LocalDateTime endtime;
private String status;
private String place;
private String message;
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}
public Integer getTid() {
	return tid;
}
public void setTid(Integer tid) {
	this.tid = tid;
}
public Integer getRid() {
	return rid;
}
public void setRid(Integer rid) {
	this.rid = rid;
}
public LocalDateTime getStarttime() {
	return starttime;
}
public void setStarttime(LocalDateTime starttime) {
	this.starttime = starttime;
}
public LocalDateTime getEndtime() {
	return endtime;
}
public void setEndtime(LocalDateTime endtime) {
	this.endtime = endtime;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}


	
}


