package com.infy.model;


public class T_Completed {
	private Integer CId;
	private Trips TId;
	private String Feedback;
	
	public Integer getCId() {
		return CId;
	}
	public void setCId(Integer cId) {
		CId = cId;
	}
	public Trips getTId() {
		return TId;
	}
	public void setTId(Trips tId) {
		TId = tId;
	}
	public String getFeedback() {
		return Feedback;
	}
	public void setFeedback(String feedback) {
		Feedback = feedback;
	}
	
}
