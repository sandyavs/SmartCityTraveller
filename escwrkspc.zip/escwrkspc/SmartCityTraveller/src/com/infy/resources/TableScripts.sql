DROP TABLE RegisterDetails;
DROP TABLE Question;
DROP TABLE Answer;
DROP TABLE Trips;
DROP TABLE T_Completed;
DROP TABLE T_Cancelled;
DROP TABLE T_Pending;


create table RegisterDetails (
RId number(12) PRIMARY KEY,
uname varchar2(30) not null,
password varchar2(30) not null,
name varchar(50) not null,
address varchar2(50) not null,
phonenumber varchar2(10) not null,
emailed varchar2(50) not null,
cityofbirth varchar2(50) not null,
dateofbirth date not null,
gender varchar2(30) not null,
securityque varchar2(30) not null,
securityans varchar2(30) not null
);

select * from RegisterDetails;
INSERT INTO RegisterDetails VALUES(12345,'SAMI','PASS','SAMILA','SAFFF0',1234567890,'SDLKHA','KERALA','12-Jan-1993','ADMIN');
INSERT INTO RegisterDetails VALUES(12365,'SAMI','PASS','SAMILA','SAFFF0',1234567890,'SDLKHA','KERALA','12-Jan-1993','NORMAL');





CREATE TABLE Question(
QId number(10) primary key,
Que varchar2(100) not null
);

INSERT INTO Question VALUES (123,'askhalshd');



CREATE TABLE Answer(
AId number(10) primary key,
Answer varchar2(100) not null,
QId number(10) references Question(QId),
RId number(12) references RegisterDetails(RId)
);


CREATE TABLE Trips(
tid number(15) primary key,
rid number(12) not null,
starttime TIMESTAMP  not null,
endtime TIMESTAMP  not null,
status varchar2(20) not null,
place varchar2(100) not null,
CONSTRAINT chk_status CHECK (Status in ('COMPLETED','CANCELLED','PENDING'))
);

select * from Trips;
Insert into Trips values(1005,1001,'2019-04-03T15:47:07.301Z','2019-04-03T15:47:07.301Z','COMPLETED','sdgahg')
Insert into Trips values(1007,1001,'2019-04-03T15:47:07.301Z','2019-04-03T15:47:07.301Z','COMPLETED','sdgahg')

CREATE TABLE T_Completed(
comId number(15) primary key,
tid number(15),
place varchar2(50) not null,
starttime TIMESTAMP not null,
endtime TIMESTAMP not null,
feedback varchar2(100) 
);

INSERT INTO T_Completed values(1001,1002,'hyd','');
select * from T_Completed;

CREATE TABLE T_Cancelled(
CanId number(15) primary key,
tid number(15),
place varchar2(50) not null,
starttime TIMESTAMP not null,
endtime TIMESTAMP not null,
feedback varchar2(100)
);

INSERT INTO T_Cancelled values(1001,1002,'hyd','');
select * from T_Cancelled;

CREATE TABLE T_Pending(
penId number(15) primary key,
tid number(15),
place varchar2(50) not null,
starttime TIMESTAMP not null,
endtime TIMESTAMP not null,
feedback varchar2(100) 
);

INSERT INTO T_Pending values(1011,1002,'hyd','');
select * from T_Pending;

select * from RegisterDetails;
select * from Question;
