package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.RegisterDetailsEntity;
import com.infy.entity.TripsEntity;
import com.infy.model.RegisterDetails;
import com.infy.model.Trips;

@Repository("tripsDao")
public class TRIPSDAOImpl implements TRIPSDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Trips addTrip(Trips trips) {
		Session session=sessionFactory.getCurrentSession();
		
		RegisterDetailsEntity cde=session.get(RegisterDetailsEntity.class,trips.getRid());
		
		if(cde == null) {
			return null;
		}

		else {
			TripsEntity tr=new TripsEntity();
			tr.setRid(trips.getRid());
			tr.setTid(trips.getTid());
			tr.setStarttime(trips.getStarttime());
			tr.setEndtime(trips.getEndtime());
			tr.setStatus(trips.getStatus());
			tr.setPlace(trips.getPlace());
			session.save(tr);
			return trips;
		}

	}

	@Override
	public List<Trips> fetchTrips(RegisterDetails trips) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<TripsEntity> cq=builder.createQuery(TripsEntity.class);
		Root<TripsEntity> root=cq.from(TripsEntity.class);
		cq.select(root);
		
		cq.where(builder.and(
				(builder.equal(root.get("rid"),trips.getRId())),
				(builder.equal(root.get("status"), "PENDING"))
				));
		
		List<TripsEntity> TripsList = session.createQuery(cq).list();
		
		if(!TripsList.isEmpty()) {
			
			
			for(int i=0;i<TripsList.size();i++) {
	               System.out.println(TripsList.get(i).getRid());
	               System.out.println(TripsList.get(i).getStarttime());
	               System.out.println(TripsList.get(i).getEndtime());
	               System.out.println(TripsList.get(i).getStatus());
	               System.out.println(TripsList.get(i).getTid());
	               System.out.println(TripsList.get(i).getPlace());
				}
			

			List<Trips> fetchedList = new ArrayList<Trips>();
			
			for(int i=0;i<TripsList.size();i++) {
				TripsEntity userDetail = session.get(TripsEntity.class,TripsList.get(i).getTid());
				Trips ob = new Trips();
				ob.setRid(userDetail.getRid());
				ob.setStarttime(userDetail.getStarttime());
				ob.setEndtime(userDetail.getEndtime());
				ob.setStatus(userDetail.getStatus());
				ob.setPlace(userDetail.getPlace());
				ob.setTid(userDetail.getTid());
				fetchedList.add(ob);
			}
			
			for(int i=0;i<TripsList.size();i++) {
               System.out.println(fetchedList.get(i).getRid());
               System.out.println(fetchedList.get(i).getStarttime());
               System.out.println(fetchedList.get(i).getEndtime());
               System.out.println(fetchedList.get(i).getStatus());
               System.out.println(fetchedList.get(i).getTid());
               System.out.println(fetchedList.get(i).getPlace());
			}

			return fetchedList;
			
		}
		
		else {
			return null;
		}
		
		
	}

	@Override
	public Trips UpdateTrip(Trips trips) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		TripsEntity tr=session.get(TripsEntity.class,trips.getTid());
		if(tr!=null){
			tr.setStarttime(trips.getStarttime());
			tr.setEndtime(trips.getEndtime());
			tr.setPlace(trips.getPlace());
			tr.setRid(trips.getRid());
			tr.setStatus(trips.getStatus());
			session.save(tr);
			return trips;
		}else{
			return null;
		}
		
	}

	@Override
	public List<Trips> fetchCancelledTrips(RegisterDetails trips) {
		// TODO Auto-generated method stub

		Session session=sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<TripsEntity> cq=builder.createQuery(TripsEntity.class);
		Root<TripsEntity> root=cq.from(TripsEntity.class);
		cq.select(root);
		
		cq.where(builder.and(
				(builder.equal(root.get("rid"),trips.getRId())),
				(builder.equal(root.get("status"), "CANCELLED"))
				));
		
		List<TripsEntity> TripsList = session.createQuery(cq).list();
		
		if(!TripsList.isEmpty()) {
			
			
			for(int i=0;i<TripsList.size();i++) {
	               System.out.println(TripsList.get(i).getRid());
	               System.out.println(TripsList.get(i).getStarttime());
	               System.out.println(TripsList.get(i).getEndtime());
	               System.out.println(TripsList.get(i).getStatus());
	               System.out.println(TripsList.get(i).getTid());
	               System.out.println(TripsList.get(i).getPlace());
				}
			

			List<Trips> fetchedList = new ArrayList<Trips>();
			
			for(int i=0;i<TripsList.size();i++) {
				TripsEntity userDetail = session.get(TripsEntity.class,TripsList.get(i).getTid());
				Trips ob = new Trips();
				ob.setRid(userDetail.getRid());
				ob.setStarttime(userDetail.getStarttime());
				ob.setEndtime(userDetail.getEndtime());
				ob.setStatus(userDetail.getStatus());
				ob.setPlace(userDetail.getPlace());
				ob.setTid(userDetail.getTid());
				fetchedList.add(ob);
			}
			
			for(int i=0;i<TripsList.size();i++) {
               System.out.println(fetchedList.get(i).getRid());
               System.out.println(fetchedList.get(i).getStarttime());
               System.out.println(fetchedList.get(i).getEndtime());
               System.out.println(fetchedList.get(i).getStatus());
               System.out.println(fetchedList.get(i).getTid());
               System.out.println(fetchedList.get(i).getPlace());
			}

			return fetchedList;
			
		}
		
		else {
			return null;
		}
		

	}

	@Override
	public List<Trips> fetchCompletedTrips(RegisterDetails trips) {
		// TODO Auto-generated method stub

		Session session=sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<TripsEntity> cq=builder.createQuery(TripsEntity.class);
		Root<TripsEntity> root=cq.from(TripsEntity.class);
		cq.select(root);
		
		cq.where(builder.and(
				(builder.equal(root.get("rid"),trips.getRId())),
				(builder.equal(root.get("status"), "COMPLETED"))
				));
		
		List<TripsEntity> TripsList = session.createQuery(cq).list();
		
		if(!TripsList.isEmpty()) {
			
			
			for(int i=0;i<TripsList.size();i++) {
	               System.out.println(TripsList.get(i).getRid());
	               System.out.println(TripsList.get(i).getStarttime());
	               System.out.println(TripsList.get(i).getEndtime());
	               System.out.println(TripsList.get(i).getStatus());
	               System.out.println(TripsList.get(i).getTid());
	               System.out.println(TripsList.get(i).getPlace());
				}
			

			List<Trips> fetchedList = new ArrayList<Trips>();
			
			for(int i=0;i<TripsList.size();i++) {
				TripsEntity userDetail = session.get(TripsEntity.class,TripsList.get(i).getTid());
				Trips ob = new Trips();
				ob.setRid(userDetail.getRid());
				ob.setStarttime(userDetail.getStarttime());
				ob.setEndtime(userDetail.getEndtime());
				ob.setStatus(userDetail.getStatus());
				ob.setPlace(userDetail.getPlace());
				ob.setTid(userDetail.getTid());
				fetchedList.add(ob);
			}
			
			for(int i=0;i<TripsList.size();i++) {
               System.out.println(fetchedList.get(i).getRid());
               System.out.println(fetchedList.get(i).getStarttime());
               System.out.println(fetchedList.get(i).getEndtime());
               System.out.println(fetchedList.get(i).getStatus());
               System.out.println(fetchedList.get(i).getTid());
               System.out.println(fetchedList.get(i).getPlace());
			}

			return fetchedList;
			
		}
		
		else {
			return null;
		}

	}

	


	


}
