package com.infy.dao;

import java.util.List;

import com.infy.model.RegisterDetails;
import com.infy.model.Trips;

public interface TRIPSDAO {
	
	public Trips addTrip(Trips trips);
	public List<Trips> fetchTrips(RegisterDetails trips);
	public Trips UpdateTrip(Trips trips);
	public List<Trips> fetchCancelledTrips(RegisterDetails trips);
	public List<Trips> fetchCompletedTrips(RegisterDetails trips);
	
    
    
    
    
}
