package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="T_Completed")
public class T_CompletedEntity {
	@Id
	private Integer CId;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="TId", unique=true)
	private TripsEntity TId;
	private String Feedback;
	
	public TripsEntity getTId() {
		return TId;
	}


	public void setTId(TripsEntity tId) {
		TId = tId;
	}


	public Integer getCId() {
		return CId;
	}


	public void setCId(Integer cId) {
		CId = cId;
	}

	public String getFeedback() {
		return Feedback;
	}


	public void setFeedback(String feedback) {
		Feedback = feedback;
	}

}
