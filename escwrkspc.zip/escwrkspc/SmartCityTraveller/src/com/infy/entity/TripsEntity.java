package com.infy.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name ="Trips")
public class TripsEntity{
	
	@Id
	private Integer tid;
	private Integer rid;
	private LocalDateTime starttime;
	private LocalDateTime endtime;
	private String status;
	private String place;
	
	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public TripsEntity() {
		System.out.println("SETTING......");	
	}
	
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		System.out.println("SETTER : "+tid);
		this.tid = tid;
		System.out.println("AFTER SETTER : "+this.tid);
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public LocalDateTime getStarttime() {
		return starttime;
	}
	public void setStarttime(LocalDateTime starttime) {
		this.starttime = starttime;
	}
	public LocalDateTime getEndtime() {
		return endtime;
	}
	public void setEndtime(LocalDateTime endtime) {
		this.endtime = endtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	


}



