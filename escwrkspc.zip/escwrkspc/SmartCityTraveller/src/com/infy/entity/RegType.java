package com.infy.entity;

public enum RegType {
	ADMIN, NORMAL;
}
