package com.infy.entity;

public enum TripStatus {
	COMPLETED, CANCELLED, PENDING;
}
