package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.TRIPSDAOImpl;
import com.infy.dao.UDAIDAOImpl;
import com.infy.entity.RegisterDetailsEntity;
import com.infy.model.RegisterDetails;
import com.infy.model.Trips;

@Service("UDAIService")
@Transactional(readOnly = true)
public class UDAIServiceImpl implements UDAIService {

	
	@Autowired
	private UDAIDAOImpl dao;

	@Autowired
	private TRIPSDAOImpl tripsDao;



@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public RegisterDetails add(RegisterDetails cust) throws Exception {
	// TODO Auto-generated method stub
	System.out.println("in service");
	RegisterDetails cd=dao.add(cust);

	if(cd==null){
		throw new Exception("Service.INVALID");
	}
	return cd;
}

@Override
@Transactional(readOnly = true)

public RegisterDetails login(String phoneORuser, String password) throws Exception {
	// TODO Auto-generated method stub

	
	RegisterDetails bs = dao.login(phoneORuser,password);
	
	if(bs==null) {
		
		throw new Exception("Service.LOGINUNSUCCESSFUL");
	}
	else{

		return bs;
	}
	

}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public RegisterDetails update(RegisterDetails user) throws Exception {
	
	RegisterDetails register=dao.update(user);
	
	return register;
	
}

@Override
@Transactional(readOnly = true)
public RegisterDetails forgotpassword(String phonenumber, String securityque, String securityans) throws Exception {
	RegisterDetails reg=dao.forgotpassword(phonenumber,securityque,securityans);
	if(reg==null) {
		throw new Exception("Service.mismatch");
	}else
	{
		return reg;
	}
}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public Trips addTrip(Trips trips) throws Exception {

	
	
	System.out.println("---------------service--------------");
	System.out.println(trips.getTid());
	System.out.println(trips.getStarttime());
	System.out.println(trips.getEndtime());
	System.out.println(trips.getStatus());
	System.out.println(trips.getRid());
	
	Trips rr=tripsDao.addTrip(trips);

	

	
	if(rr != null) {
		System.out.println("IN SERVICE TRY");
		return rr;
	}
	
	else {
		throw new Exception("dao.no_user_Exists");
		
	}
	
}

@Override
public List<Trips> fetchTrips(RegisterDetails trips) throws Exception {
	// TODO Auto-generated method stub
	
	List<Trips> list = tripsDao.fetchTrips(trips);
	
	if(list.size() == 0) {
		System.out.println("IN SERVICE CATCH");
		throw new Exception("Service.NoSuchUser");
	}else {
		return list;
	}
	
}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public Trips UpdateTrip(Trips trips) throws Exception {
	Trips tr=tripsDao.UpdateTrip(trips);
	
	if(tr == null){
		return null;
	}
	
	else{
		return tr;
	}
}


@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public List<Trips> fetchCancelledTrips(RegisterDetails trips) throws Exception {
	// TODO Auto-generated method stub
	
	List<Trips> tr = new ArrayList<Trips>();
	tr = tripsDao.fetchCancelledTrips(trips);
	if(tr == null){
		return null;
	}
	else{
		return tr;
	}
}


@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public List<Trips> fetchCompletedTrips(RegisterDetails trips) throws Exception {
	// TODO Auto-generated method stub
	
	List<Trips> tr = new ArrayList<Trips>();
    tr = tripsDao.fetchCompletedTrips(trips);
	if(tr == null){
		return null;
	}
	
	else{
		return tr;
	}

}



	
}


