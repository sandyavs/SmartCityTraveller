package com.infy.service;

import java.util.List;

import com.infy.entity.RegisterDetailsEntity;
import com.infy.model.RegisterDetails;
import com.infy.model.Trips;

public interface UDAIService {



	public RegisterDetails add(RegisterDetails addUser) throws Exception;
	public RegisterDetails login(String phoneORuser, String password) throws Exception;
	public RegisterDetails update(RegisterDetails user) throws Exception;
	public RegisterDetails forgotpassword(String phonenumber, String securityque, String securityans) throws Exception;
	
	public Trips addTrip(Trips trips) throws Exception;
	public List<Trips> fetchTrips(RegisterDetails trips) throws Exception;
	public Trips UpdateTrip(Trips trips) throws Exception;
	public List<Trips> fetchCancelledTrips(RegisterDetails trips) throws Exception;
	public List<Trips> fetchCompletedTrips(RegisterDetails trips) throws Exception;
	
}
